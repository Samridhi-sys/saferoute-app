# SafeRoute AI — backend

Optional Node/Express backend for the sign-in and free-trial gate.

The front-end works **without** this server (it falls back to `localStorage`, which
is fine for a static GitHub Pages demo). Run this server when you want sign-ins
that are actually verified and a trial clock that can't be reset by clearing
browser data.

## Run it

```bash
cd server
npm install
cp .env.example .env     # then fill in the values
npm start
```

Open http://localhost:3000 — the server also serves the front-end, so the whole
prototype runs on one origin.

## Setting up Google Sign-In

1. Google Cloud Console → **APIs & Services → Credentials → Create credentials →
   OAuth client ID**, application type **Web application**.
2. Under *Authorized JavaScript origins* add `http://localhost:3000` (and your
   live site URL when you deploy).
3. Put the Client ID in **two** places:
   - `server/.env` → `GOOGLE_CLIENT_ID=...`
   - `index.html` → the `GOOGLE_CLIENT_ID` constant near the bottom

Both must match, or token verification will reject the sign-in.

## Endpoints

| Method | Path                | Purpose |
|--------|---------------------|---------|
| POST   | `/api/auth/google`  | Verifies a Google ID token, creates a session |
| POST   | `/api/auth/trial`   | Starts or resumes the 30-day free trial |
| GET    | `/api/auth/me`      | Current user + days left in trial |
| POST   | `/api/auth/logout`  | Clears the session cookie |
| GET    | `/api/profile`      | Saved route + guardian for the signed-in user |
| PUT    | `/api/profile`      | Saves route + guardian |
| GET    | `/api/health`       | Used by the page to detect whether a backend exists |

## How sessions work

A signed JWT in an **httpOnly cookie** — so page JavaScript can't read or forge
it. The trial start date lives on the server, keyed to that cookie, which is why
clearing `localStorage` no longer grants a fresh 30 days.

## Storage

`data/db.json`, written by `store.js`. There's no database to install. When you
move to production, replace the four functions in `store.js` with real queries
(Postgres, Mongo, Supabase, whatever) — nothing else has to change.

## Before deploying

- Set a real `JWT_SECRET` (`node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`)
- Set `NODE_ENV=production` so cookies are sent `secure` + `SameSite=None`
- Set `ALLOWED_ORIGIN` to your site URL instead of the permissive default
- Serve over HTTPS — Google Sign-In requires it on anything but `localhost`
- `data/` and `.env` are gitignored; don't commit them
